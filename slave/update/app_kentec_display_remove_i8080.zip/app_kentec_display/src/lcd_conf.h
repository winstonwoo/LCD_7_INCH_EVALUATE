#ifndef LCD_CONF_H_
#define LCD_CONF_H_

#define LCD_PART_NUMBER K70DWN0V1F
#endif /* LCD_CONF_H_ */
