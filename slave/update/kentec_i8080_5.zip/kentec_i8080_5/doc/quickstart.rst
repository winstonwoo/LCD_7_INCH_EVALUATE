Kentec Text Display - Quickstart Guide 
====================================== 

Storing text in flash 
+++++++++++++++++++++

#. Create the project ``flash_write`` in xTIMEcomposer, copy the necessary files and compile.
#. Right click the project and go to Flash as -> Flash Configurations. 
#. In XFlash Options, select the SPI spec file ``MX25L6445E.spec`` available at ``flash_write/src``. Also set the boot partition size (Eg. 0x10000).
#. Click on Apply and Flash buttons. Wait for the message ``xflash succeeded``.
#. Run ``flash_write``. Wait for the message ``Data partition written!``
#. The text data to be stored in flash can be changed in the ``my_data`` array in ``flash_write.xc``. The text size is defined by TEXT_SIZE. The starting location of text data in the data partition ``START_LOC`` is set to 0x100, which can also be altered. 


Run the Application 
+++++++++++++++++++ 

The slave-side application program is run on the Kentec Display board following the steps below.

#. Create the project ``app_text_display_slave``. Copy the necessary files and also the dependent modules listed in the ``Makefile``. Compile the project.
#. Run ``app_text_display_slave``.
#. The DATA_READ_DELAY defined in i8080_slave.h may be adjusted according to the timing set in the master side.

For testing, XK-1A board has been chosen as the master board. Setup the connections between the master and the slave boards. The control and data lines for i8080 interfacing are established. The master-side application program is run on a different xTIMEcomposer window following the steps below. 

#. Create the project ``app_text_display_master``. Copy the necessary files and also the dependent modules listed in the ``Makefile``. Compile the project.
#. Run ``app_text_display_master``.
#. The row and column coordinates of LCD where the text should be display are defined in ``commands.h``. The start and end addresses of text data in the data partition of the flash are also defined in this file.  


